# -*- coding: utf-8 -*-
"""
/***************************************************************************
 constraintsAnalysis
                                 A QGIS plugin
 Constraints analysis version 1.0
                             -------------------
        begin                : 2017-03-23
        copyright            : (C) 2017 by Geospatial Planning Advisors
        email                : geoplanadv@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 This script initializes the plugin, making it known to QGIS.
"""


# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    """Load constraintsAnalysis class from file constraintsAnalysis.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    #
    from .constraints_analysis import constraintsAnalysis
    return constraintsAnalysis(iface)
